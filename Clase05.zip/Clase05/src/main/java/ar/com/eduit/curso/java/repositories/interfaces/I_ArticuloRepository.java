package ar.com.eduit.curso.java.repositories.interfaces;

import ar.com.eduit.curso.java.entities.Articulo;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface I_ArticuloRepository {
    void save(Articulo articulo);
    void remove(Articulo articulo);
    default Articulo getById(int id){
        //select * from articulos where id=id
        return getAll()
                .stream()
                .filter(a->a.getId()==id)
                .findFirst()
                .orElse(new Articulo());
    }
    List<Articulo> getAll();
    default List<Articulo> getLikeDescripcion(String descripcion){
        //select * from articulos where descripcion like '%descripcion%';
        //Java clasico
        
        /*
        List<Articulo>list=new ArrayList();
        if(descripcion==null) return list;
        for(Articulo a:getAll()){
            if(a.getDescripcion().toLowerCase().contains(descripcion.toLowerCase())){
                list.add(a);
            }
        }
        return list;
        */
        if(descripcion==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(a->a.getDescripcion().toLowerCase().contains(descripcion.toLowerCase()))
                .collect(Collectors.toList());
    }
}
