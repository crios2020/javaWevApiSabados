package ar.com.eduit.curso.java.rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/test")
public class Test {
    
    @GET
    @Produces(MediaType.TEXT_HTML)
    public String info(){
        return "<h1>Servicio activo!</h1>";
    }
    
    @GET
    @Path("/info")
    @Produces(MediaType.TEXT_PLAIN)
    public String info2(){
        return "<h1>Servicio activo!</h1>";
    }
    
    @GET
    @Path("/saludo")
    @Produces(MediaType.TEXT_HTML)
    public String saludo(@QueryParam("nombre") String nombre, @QueryParam("edad") int edad){
        return "<h1>Hola "+nombre+" su edad "+edad+" años</h1>";
    }
    
}
