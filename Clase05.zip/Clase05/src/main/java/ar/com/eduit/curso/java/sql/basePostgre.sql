/*
        Base de datos elephantsql.com

        Server: tuffi.db.elephantsql.com (tuffi-01)
        User & DB: ejubsvdq
        Password: GUgF2j314hMc-TZsx-7Pt0N11AmG_0Sr
        URL: postgres://ejubsvdq:GUgF2j314hMc-TZsx-7Pt0N11AmG_0Sr@tuffi.db.elephantsql.com/ejubsvdq

*/


drop table if exists articulos ;
drop table if exists clientes ;
create table articulos(
    id serial primary key,
    descripcion varchar(25) not null,
    precio float8 not null,
    stock int not null
);

alter table articulos
    add constraint ck_articulos_precio
    check (precio>=0);

alter table articulos 
    add constraint ck_articulos_stock
    check (stock>=0);

create table clientes(
    id serial primary key,
    nombre varchar(25) not null,
    apellido varchar(25) not null,
    edad int,
    direccion varchar(25)
);

alter table clientes
    add constraint ck_clientes_edad
    check (edad >=18 and edad <=120);

select * from articulos;
select * from clientes;

