package clienteclase03;

import ar.com.eduit.curso.java.entities.Articulo;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;

public class ClienteClase03 {

    public static void main(String[] args) throws Exception{
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio de normalización de direcciones --");
        System.out.println(responseBody("http://servicios.usig.buenosaires.gob.ar/normalizar?direccion=Medrano"));
        System.out.println("****************************************************");
        
        String server="http://localhost:8082/Server";
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio AltaArticulo");
        System.out.println(responseBody(server+"/ArticuloAlta?descripcion=Telefono&precio=300&stock=10"));
        System.out.println("****************************************************");
        
                
        System.out.println("****************************************************");
        System.out.println("-- Servicio AltaArticulo");
        System.out.println(responseBody(server+"/ArticuloAlta?descripcion=Bicicleta&precio=200&stock=10"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio AltaArticulo");
        System.out.println(responseBody(server+"/ArticuloAlta?descripcion=Scooter&precio=3000&stock=10"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio all");
        System.out.println(responseBody(server+"/ArticuloAll"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio likeDescripcion");
        System.out.println(responseBody(server+"/ArticuloLikeDescripcion?descripcion=bi"));
        System.out.println("****************************************************");
        
        
        // Gson.fromGson()
        //Type listType=new TypeToken<List<Articulo>>(){}.getType();
        //List<Articulo>list=new Gson().fromJson(responseBody(server+"/ArticuloAll"), listType);
        
        List<Articulo>list=new Gson()
                .fromJson(responseBody(server+"/ArticuloAll"), new TypeToken<List<Articulo>>(){}.getType());
        
        list.forEach(System.out::println);
        

        // Api rest
        
    }
    
    private static String responseBody(String url) throws InterruptedException, IOException {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest
                .newBuilder()
                .uri(URI.create(url))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if(response.statusCode()==200){
            System.out.println("\033[32mstatus: "+response.statusCode());
        }else{
            System.out.println("\033[31mstatus: "+response.statusCode());
        }
        response.headers().map().forEach((k, v) -> System.out.println(k + " " + v));
        return response.body();
    }
}
