package ar.com.eduit.curso.java.repositories.test;

import ar.com.eduit.curso.java.connector.Connector;
import ar.com.eduit.curso.java.entities.Articulo;
import ar.com.eduit.curso.java.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.repositories.jdbc.ArticuloRepository;
//import ar.com.eduit.curso.java.repositories.list.ArticuloRepositoryFactory;

public class TestRepository {
    public static void main(String[] args) {
        //I_ArticuloRepository ar=ArticuloRepositoryFactory.getArticuloRepository();
        I_ArticuloRepository ar=new ArticuloRepository(Connector.getConnection());
        ar.save(new Articulo("Parlantes USB",20,20));
        ar.save(new Articulo("Teclado",30,30));
        ar.save(new Articulo("Mouse",15,10));
        ar.save(new Articulo("Monitor 19'",2000,20));
        ar.save(new Articulo("CPU",4000,10));
        
        Articulo articulo=new Articulo("Celular J8",4000,10);
        ar.save(articulo);
        System.out.println(articulo);
        
        ar.getAll().forEach(System.out::println);
        
        System.out.println("****************************************************");
        ar.getLikeDescripcion("ar").forEach(System.out::println);

        

    }
}
