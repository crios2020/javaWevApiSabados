package ar.com.eduit.curso.java.repositories.test;

import ar.com.eduit.curso.java.connector.Connector;
import java.sql.ResultSet;
import java.time.LocalTime;

public class TestConnector {
    public static void main(String[] args) {
        time();
        try (ResultSet rs=Connector.getConnection().createStatement().executeQuery("select version()")){
            if(rs.next()){
                System.out.println(rs.getString(1));
            }else{
                System.out.println("No se pudo conectar");
            }
        } catch (Exception e) {
            System.out.println("No se pudo conectar");
            System.out.println(e);
        }
        time();
    }

    private static void time() {
        System.out.println(LocalTime.now());
    }
}
