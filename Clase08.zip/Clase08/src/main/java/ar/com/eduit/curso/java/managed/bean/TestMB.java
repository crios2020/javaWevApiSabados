package ar.com.eduit.curso.java.managed.bean;

import ar.com.eduit.curso.java.enums.EstadoCivil;
import java.io.Serializable;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named("testMB")
@SessionScoped
public class TestMB implements Serializable{ //testMB
    private String nombre="xxx";
    private String apellido="xxx";
    private String estadoCivil="";
    private String mensaje="";

    public void save(){
        mensaje="Se ingreso a "+nombre+" "+apellido+" "+estadoCivil;
        nombre="";
        apellido="";
        estadoCivil="";
    }
    
    public List<EstadoCivil>getEstados(){
        return List.of(EstadoCivil.values());
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
    
    
}
