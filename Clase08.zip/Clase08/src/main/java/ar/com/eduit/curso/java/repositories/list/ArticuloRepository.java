package ar.com.eduit.curso.java.repositories.list;

import ar.com.eduit.curso.java.entities.Articulo;
import ar.com.eduit.curso.java.repositories.interfaces.I_ArticuloRepository;
import java.util.ArrayList;
import java.util.List;

public class ArticuloRepository implements I_ArticuloRepository{
    List<Articulo>list;

    public ArticuloRepository() {
        this.list = new ArrayList();
    }

    @Override
    public void save(Articulo articulo) {
        if(articulo==null) return;
        list.add(articulo);
    }

    @Override
    public void remove(Articulo articulo) {
        list.remove(articulo);
    }

    @Override
    public List<Articulo> getAll() {
        return list;
    }
    
}
