package clienteclase03;

import ar.com.eduit.curso.java.entities.Articulo;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;

public class ClienteClase03 {

    public static void main(String[] args) throws Exception{
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio de normalización de direcciones --");
        System.out.println(responseBody("http://servicios.usig.buenosaires.gob.ar/normalizar?direccion=Medrano"));
        System.out.println("****************************************************");
        
        String server="http://localhost:8082/Server/webresources";
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio Clientes Info");
        System.out.println(responseBody(server+"/clientes/v1"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio Clientes Alta");
        System.out.println(responseBody(server+"/clientes/v1/alta?nombre=Liliana&apellido=Garcia&edad=30&direccion=Lima_222"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio Clientes Baja");
        System.out.println(responseBody(server+"/clientes/v1/baja?id=8"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio Clientes All");
        System.out.println(responseBody(server+"/clientes/v1/all"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio Clientes LikeApellido");
        System.out.println(responseBody(server+"/clientes/v1/likeApellido?apellido=pe"));
        System.out.println("****************************************************");
        
                
        System.out.println("****************************************************");
        System.out.println("-- Servicio Articulos Info");
        System.out.println(responseBody(server+"/articulos/v1"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio AltaArticulo");
        System.out.println(responseBody(server+"/articulos/v1/alta?descripcion=Telefono&precio=300&stock=10"));
        System.out.println("****************************************************");
        
                
        System.out.println("****************************************************");
        System.out.println("-- Servicio AltaArticulo");
        System.out.println(responseBody(server+"/articulos/v1/alta?descripcion=Bicicleta&precio=200&stock=10"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio AltaArticulo");
        System.out.println(responseBody(server+"/articulos/v1/alta?descripcion=Scooter&precio=3000&stock=10"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio BajaArticulo");
        System.out.println(responseBody(server+"/articulos/v1/baja?id=10"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio all");
        System.out.println(responseBody(server+"/articulos/v1/all"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio likeDescripcion");
        System.out.println(responseBody(server+"/articulos/v1/likeDescripcion?descripcion=bi"));
        System.out.println("****************************************************");
        
        
        // Migrar a JAKARTA 9
        
        
        // Gson.fromGson()
        //Type listType=new TypeToken<List<Articulo>>(){}.getType();
        //List<Articulo>list=new Gson().fromJson(responseBody(server+"/ArticuloAll"), listType);
        /*
        List<Articulo>list=new Gson()
                .fromJson(responseBody(server+"/ArticuloAll"), new TypeToken<List<Articulo>>(){}.getType());
        
        list.forEach(System.out::println);
        */

        // Api rest
        
    }
    
    private static String responseBody(String url) throws InterruptedException, IOException {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest
                .newBuilder()
                .uri(URI.create(url))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if(response.statusCode()==200){
            System.out.println("\033[32mstatus: "+response.statusCode());
        }else{
            System.out.println("\033[31mstatus: "+response.statusCode());
        }
        response.headers().map().forEach((k, v) -> System.out.println(k + " " + v));
        return response.body();
    }
}
