package ar.com.eduit.curso.java.connector;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connector {
    
    private static String driver="org.postgresql.Driver";
    private static String url="jdbc:postgresql://tuffi.db.elephantsql.com:5432/ejubsvdq";
    private static String user="ejubsvdq";
    private static String pass="GUgF2j314hMc-TZsx-7Pt0N11AmG_0Sr";
    
    
    /*
    private static String driver="org.mariadb.jdbc.Driver";
    private static String url="jdbc:mariadb://localhost:3306/javaWebSabado";
    private static String user="root";
    private static String pass="";
    */
    private static Connection conn=null;
    private Connector(){}
    public synchronized static Connection getConnection(){
        try {
            if(conn==null || conn.isClosed()){
                Class.forName(driver);
                conn=DriverManager.getConnection(url, user, pass);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return conn;
    }
}
