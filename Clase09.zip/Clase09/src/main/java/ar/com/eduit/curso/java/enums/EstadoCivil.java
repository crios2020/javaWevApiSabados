package ar.com.eduit.curso.java.enums;

public enum EstadoCivil {
    SOLTERO,
    CASADO,
    VIUDO,
    DIVORCIADO
}
