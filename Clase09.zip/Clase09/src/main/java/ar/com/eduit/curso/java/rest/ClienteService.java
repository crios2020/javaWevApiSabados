package ar.com.eduit.curso.java.rest;

import ar.com.eduit.curso.java.connector.Connector;
import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.repositories.interfaces.I_ClienteRepository;
import ar.com.eduit.curso.java.repositories.jdbc.ClienteRepository;
import com.google.gson.Gson;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

@Path("/clientes/v1")
public class ClienteService {
    private I_ClienteRepository cr=new ClienteRepository(Connector.getConnection());
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String info(){
        return "Servicio Clientes V1 Activo!";
    }
    
    @GET
    @Path("/alta")
    @Produces(MediaType.TEXT_PLAIN)
    public String save(@QueryParam("nombre") String nombre, @QueryParam("apellido") String apellido, 
            @QueryParam("edad") int edad, @QueryParam("direccion") String direccion){
        Cliente cliente=new Cliente(nombre, apellido, edad, direccion);
        cr.save(cliente);
        return cliente.getId()+"";
    }
    
    @GET
    @Path("/baja")
    @Produces(MediaType.TEXT_PLAIN)
    public String remove(@QueryParam("id") int id){
        try {
            cr.remove(cr.getById(id));
            return "true";
        } catch (Exception e) {
            return "false";
        }
    }
    
    @GET
    @Path("/all")
    @Produces(MediaType.APPLICATION_JSON)
    public String all(){
        return new Gson().toJson(cr.getAll());
    }
    
    @GET
    @Path("/likeApellido")
    @Produces(MediaType.APPLICATION_JSON)
    public String likeApellido(@QueryParam("apellido")String apellido){
        return new Gson().toJson(cr.getLikeApellido(apellido));
    }
    
}
