package ar.com.eduit.curso.java.rest;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;


@ApplicationPath("/webresources")
public class JaxRSConfig extends Application{
    
}
