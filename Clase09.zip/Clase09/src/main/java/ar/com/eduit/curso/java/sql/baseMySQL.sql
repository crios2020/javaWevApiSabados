drop database if exists javaWebSabado;
create database javaWebSabado;
use javaWebSabado; 

drop table if exists articulos ;
drop table if exists clientes ;
create table articulos(
    id int auto_increment primary key,
    descripcion varchar(25) not null,
    precio double not null,
    stock int not null
);

alter table articulos
    add constraint ck_articulos_precio
    check (precio>=0);

alter table articulos 
    add constraint ck_articulos_stock
    check (stock>=0);

create table clientes(
    id int auto_increment primary key,
    nombre varchar(25) not null,
    apellido varchar(25) not null,
    edad int,
    direccion varchar(25)
);

alter table clientes
    add constraint ck_clientes_edad
    check (edad >=18 and edad <=120);

select * from articulos;
select * from clientes;

