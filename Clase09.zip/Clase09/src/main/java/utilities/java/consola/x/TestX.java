package utilities.java.consola.x;

/**
 * Clase para testear el funcionamiento de consola X Tener en cuenta que
 * Netbeans 12.4 con proyectos Maven no funcionan alguna utilidades.
 *
 * @author carlos
 */
public class TestX {

    public static void main(String[] args) {

        //métodos print y println
        X.print("hola");
        X.println("hola");
        X.println(ConsoleColors.BLUE+"Hola"+ConsoleColors.RESET);
        
        //métodos input String
        //X.print("Ingrese un String: ");
        //String st=X.input();
        //X.println(st);
        //String st2=X.input("Ingrese un String: ");
        //X.println(st2);
        
        //métodos input int
        //X.print("Ingrese un entero: ");
        //int in=X.inputInt();
        //X.println(in);
        //int in2=X.inputInt("Ingrese un entero: ");
        //X.println(in2);
        
        //métodos input float
        //X.print("ingrese un float: ");
        //float fl=X.inputFloat();
        //X.println(fl);
        //float fl2=X.inputFloat("ingrese un float: ");
        //X.println(fl2);
        
        //métodos input double
        //X.println("ingrese un double: ");
        //double dl=X.inputDouble();
        //X.println(dl);
        //double dl2=X.inputDouble("ingrese un double: ");
        //X.println(dl2);
        
        //método request
        X.print(X.request("Desea un café? S o N: "));
    }
}
