package utilities.java.swing.panel;

/**
 * Clase para testear la Utilidad Box
 *
 * @author carlos
 */
public class TestBox {

    public static void main(String[] args) {
        //Método .msgBox()
        //Box.msgBox("Hola Mundo!");

        //Método .input()
        //String st=Box.input("Ingrese un String: ");
        //Box.msgBox(st);
        
        //Método .inputInt()
        //int in=Box.inputInt("Ingrese un int: ");
        //Box.msgBox(in);
        
        //Método .inputFloat()
        //float fl=Box.inputFloat("Ingrese un float: ");
        //Box.msgBox(fl);
        
        //Método .inputDouble()
        //double dl=Box.inputDouble("Ingrese un double: ");
        //Box.msgBox(dl);
        
        //Método .request()
        //boolean bo=Box.request("Desea un café?");
        //Box.msgBox(bo);
    }
}
