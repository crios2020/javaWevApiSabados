package ar.com.eduit.curso.java.repositories.rest;

import ar.com.eduit.curso.java.entities.Articulo;
import ar.com.eduit.curso.java.repositories.interfaces.I_ArticuloRepository;
import java.util.List;

public class ArticuloRepository implements I_ArticuloRepository{

    String url;

    public ArticuloRepository(String url) {
        this.url = url;
    }

    @Override
    public void save(Articulo articulo) {
        String urlService=url+"/alta?descripcion="+articulo.getDescripcion()
                +"&precio="+articulo.getPrecio()+"&stock="+articulo.getStock();
        try {
            articulo.setId(Integer.parseInt(ClienteHttp.responseBody(urlService)));
        } catch (Exception e) {
            System.out.println(e);
        }
        
    }

    @Override
    public void remove(Articulo articulo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Articulo> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
