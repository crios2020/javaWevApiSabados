package ar.com.eduit.curso.java.repositories.rest;

import ar.com.eduit.curso.java.entities.Articulo;
import ar.com.eduit.curso.java.repositories.interfaces.I_ArticuloRepository;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.List;

public class ArticuloRepository implements I_ArticuloRepository{

    String url;

    public ArticuloRepository(String url) {
        this.url = url;
    }

    @Override
    public void save(Articulo articulo) {
        String urlService=url+"/alta?descripcion="+articulo.getDescripcion()
                +"&precio="+articulo.getPrecio()+"&stock="+articulo.getStock();
        urlService=urlService.replaceAll(" ", "_");
        try {
            articulo.setId(Integer.parseInt(ClienteHttp.responseBody(urlService)));
        } catch (Exception e) {
            System.out.println(e);
        }
        
    }

    @Override
    public void remove(Articulo articulo) {
        String urlService=url+"/baja?id="+articulo.getId();
        ClienteHttp.responseBody(urlService);
    }

    @Override
    public List<Articulo> getAll() {
        String urlService=url+"/all";
        Type listType=new TypeToken<List<Articulo>>(){}.getType();
        List<Articulo>list=new Gson().fromJson(ClienteHttp.responseBody(urlService), listType);
        return list;
    }
    
}
