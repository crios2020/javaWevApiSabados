package ar.com.eduit.curso.java.repositories.rest;

import ar.com.eduit.curso.java.entities.Articulo;
import ar.com.eduit.curso.java.entities.Cliente;
import ar.com.eduit.curso.java.repositories.interfaces.I_ClienteRepository;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.List;

public class ClienteRepository implements I_ClienteRepository{
    String url;

    public ClienteRepository(String url) {
        this.url = url;
    }

    @Override
    public void save(Cliente cliente) {
        String urlService=url+"/alta?nombre="+cliente.getNombre()
                +"&apellido="+cliente.getApellido()+"&edad="+cliente.getEdad()
                +"&direccion="+cliente.getDireccion();
        urlService=urlService.replaceAll(" ", "_");
        try {
            cliente.setId(Integer.parseInt(ClienteHttp.responseBody(urlService)));
        } catch (Exception e) {
            System.out.println(e);
        }
        
    }

    @Override
    public void remove(Cliente cliente) {
        String urlService=url+"/baja?id="+cliente.getId();
        ClienteHttp.responseBody(urlService);
    }

    @Override
    public List<Cliente> getAll() {
        String urlService=url+"/all";
        Type listType=new TypeToken<List<Cliente>>(){}.getType();
        List<Cliente>list=new Gson().fromJson(ClienteHttp.responseBody(urlService), listType);
        return list;
    }
}
