package ar.com.eduit.curso.java.repositories.test;

import ar.com.eduit.curso.java.entities.Articulo;
import ar.com.eduit.curso.java.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.repositories.rest.ArticuloRepository;

public class TestRepository {
    public static void main(String[] args) {
        String urlArticulos="http://localhost:8084/Server/webresources/articulos/v1";
        I_ArticuloRepository ar=new ArticuloRepository(urlArticulos);
        ar.save(new Articulo("Parlantes_USB",20,20));
        ar.save(new Articulo("Teclado",30,30));
        ar.save(new Articulo("Mouse",15,10));
        ar.save(new Articulo("Monitor_19'",2000,20));
        ar.save(new Articulo("CPU",4000,10));
        
        Articulo articulo=new Articulo("Celular_J8",4000,10);
        ar.save(articulo);
        System.out.println(articulo);
        
//        ar.getAll().forEach(System.out::println);
//        
//        System.out.println("****************************************************");
//        ar.getLikeDescripcion("ar").forEach(System.out::println);

        

    }
}
