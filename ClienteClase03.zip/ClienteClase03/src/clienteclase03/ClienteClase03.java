package clienteclase03;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class ClienteClase03 {

    public static void main(String[] args) throws Exception{
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio de normalización de direcciones --");
        System.out.println(responseBody("http://servicios.usig.buenosaires.gob.ar/normalizar?direccion=Medrano"));
        System.out.println("****************************************************");
        
        String server="http://localhost:8080/Clase03";
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio AltaArticulo");
        System.out.println(responseBody(server+"/ArticuloAlta?descripcion=Telefono&precio=300&stock=10"));
        System.out.println("****************************************************");
        
                
        System.out.println("****************************************************");
        System.out.println("-- Servicio AltaArticulo");
        System.out.println(responseBody(server+"/ArticuloAlta?descripcion=Bicicleta&precio=200&stock=10"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio AltaArticulo");
        System.out.println(responseBody(server+"/ArticuloAlta?descripcion=Scooter&precio=3000&stock=10"));
        System.out.println("****************************************************");
        
        System.out.println("****************************************************");
        System.out.println("-- Servicio all");
        System.out.println(responseBody(server+"/ArticuloAll"));
        System.out.println("****************************************************");
        
        // Gson.fromGson()
        
        // Api rest
        
    }
    
    private static String responseBody(String url) throws InterruptedException, IOException {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest
                .newBuilder()
                .uri(URI.create(url))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        response.headers().map().forEach((k, v) -> System.out.println(k + " " + v));
        return response.body();
    }
}
